package MyPractice1;

import java.util.Arrays;

public class VariableEx3 {
	
	void display()
	{
	int []a= {1,2,3,4,5};
	int []b= {1,2,3,4,5};
	
	
	boolean flag=Arrays.equals(a,b);
	
	}
	
	
	
	

	public static void main(String[] args) {
		
		VariableEx3 obj=new VariableEx3();
		obj.display();
		

}
	
}
