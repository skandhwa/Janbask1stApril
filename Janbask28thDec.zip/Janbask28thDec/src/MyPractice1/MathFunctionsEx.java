package MyPractice1;

public class MathFunctionsEx {

	public static void main(String[] args) {
		
		float x=23456.545f;
		
		int y=Math.round(x);
		
		System.out.println(y);
		
		
		int p=-32432432;
		
		int z=Math.abs(p);
		System.out.println(z);
		
		float q=-3454354.345435f;
		
		float m=Math.abs(q);
		
		System.out.println(m);
		
	
		
		
		
		
		
		
		
		

	}

}
