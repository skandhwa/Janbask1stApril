package MyPractice1;

public class VariableEx1 
{
	
	int x=10;/////instance variable
	
	
	
	void display()
	{
		System.out.println("I am Saurabh");
		int y=x+20;
		System.out.println(y);
		
	}
	
	void test()
	{
		int p=x+40;
		
		System.out.println(p);
		
		//int q=y+40;
		
		
	}
	
	
	

	public static void main(String[] args) {
		
		VariableEx1 obj=new VariableEx1();
		obj.display();
		obj.test();
		
		

	}

}
