package MyPractice1;

public class VariableEx {
	
	int x=20;
	
	void add()
	{
		int p=x+20;
		System.out.println(p);
	}
	
	void subtract()
	{
		int q=x-20;
		System.out.println(q);
	}
	

	public static void main(String[] args) {
		
		VariableEx obj=new VariableEx();
		obj.add();
		obj.subtract();
		
		
		

	}

}
