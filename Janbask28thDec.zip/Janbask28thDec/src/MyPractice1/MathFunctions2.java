package MyPractice1;

public class MathFunctions2 {

	public static void main(String[] args) {
		
		int x=20;
		int y=30;
		int z=50;
		
		
		int max=Math.max(x, y);
		
		System.out.println(max);
		
		int p=225;
		double k=Math.sqrt(p);
		System.out.println(k);
		
	int n=	Math.addExact(x, y);
	
	System.out.println(n);
	
	
	
		
		
		
		
		

	}

}
