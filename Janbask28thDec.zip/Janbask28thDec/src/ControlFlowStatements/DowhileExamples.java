package ControlFlowStatements;

public class DowhileExamples {

	public static void main(String[] args) {
		
		int x=10;
		do
		{
			System.out.println(x);///10
			x++;
		}
		while(x<5);///10<15
		
		
		
		

	}

}
