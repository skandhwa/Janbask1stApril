package ControlFlowStatements;

public class LargestBWThreeNumbers {

	public static void main(String[] args) {
		
		int a=20;
		int b=30;
		int c=40;
		
		if(a>b)
		{
			if(a>c)
			{
				System.out.println("Maximum is "+a);
			}
			else
			{
				System.out.println("Maximum is "+c);
			}
		}
		else
		{
			if(b>c)
			{
				System.out.println("Maximum is "+b);
			}
			else
			{
				System.out.println("Maximum is "+c);
			}
		}
		
		

	}

}
