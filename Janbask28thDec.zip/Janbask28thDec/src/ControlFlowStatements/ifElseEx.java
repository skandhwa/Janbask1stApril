package ControlFlowStatements;

public class ifElseEx {

	public static void main(String[] args) {
		
		int a=40;
		int b=30;
		
		if(a>b)
		{
			System.out.println("Maximum is "+a);
		}
		
		else
		{
			System.out.println("Maximum is "+b);
		}
		
		
		

	}

}
