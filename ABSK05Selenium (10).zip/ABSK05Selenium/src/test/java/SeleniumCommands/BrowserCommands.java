package SeleniumCommands;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BrowserCommands {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver= new ChromeDriver();
		driver.get("https://www.google.com");
		String URL1=driver.getCurrentUrl();
		System.out.println(URL1);
		
		
	      String Title=	driver.getTitle();
	       System.out.println(Title);
	       driver.findElement(By.xpath("(//a[@class='gb_I'])[1]")).click();
	       Thread.sleep(3000);
	       String URL2=driver.getCurrentUrl();
			System.out.println(URL2);
			
			
		String PageSource=	driver.getPageSource();
		System.out.println(PageSource);
	
	
	
		

	}

}
