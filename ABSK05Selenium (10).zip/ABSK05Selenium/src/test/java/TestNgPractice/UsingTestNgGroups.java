package TestNgPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class UsingTestNgGroups {
	
	WebDriver driver;
	
	@Test(groups= {"regression"})
	public void start()
	{
		
		System.out.println("Hello");
	}
	
	@Test(groups= {"regression"})
	public void checktitle()
	{
		
		System.out.println("Checking Title");
	}
	
	@Test(groups= {"sanity"})
	public void test2()
	{
		
		System.out.println("Checking test2");
	}
	
	
	
	

}
