package TestNgPractice;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class TestNgDataProviderExample {
	
	WebDriver driver;
	
	@DataProvider(name="MyDp1")
	public Object[][] method()
	{

	return new Object[][]
			{{"Java"},{"Selenium testing"},{"php"},{"xml"}

	};
	}
	
	@Test(dataProvider="MyDp1")
	public void SearchValues(String Keyword)
	{
		driver=new ChromeDriver();
		driver.get("https://www.google.com");
		driver.manage().window().maximize();
	WebElement ele=	driver.findElement(By.xpath("//textarea[@class='gLFyf']"));
	ele.sendKeys(Keyword);
	ele.sendKeys(Keys.ENTER);
	
		
	}
	
	
	
	

}
