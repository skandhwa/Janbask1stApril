package AdvanceSelenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class DragNDropSelenium {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver= new ChromeDriver();
		driver.get("https://grotechminds.com/drag-and-drop/");
		driver.manage().window().maximize();
		Actions act=new Actions(driver);
	WebElement Src=	driver.findElement(By.xpath("//img[@id='drag1']"));
	WebElement Src2=driver.findElement(By.xpath("//img[@id='drag7']"));
	
	WebElement Target=driver.findElement(By.xpath("//div[@id='div2']"));
	Thread.sleep(3000);
	act.dragAndDrop(Src, Target).build().perform();
	act.dragAndDrop(Src2, Target).build().perform();
	
	
	
	
		
		
		
		

	}

}
