package JanbaskPractice;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class FirstTestCase {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.wikipedia.org/");
		driver.manage().window().maximize();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='searchInput']")).sendKeys("Selenium Java");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("(//span[text()='Create account'])[1]")).click();
		Thread.sleep(3000);
	String URL1=driver.getCurrentUrl();
	System.out.println(URL1);
	Thread.sleep(3000);
	driver.navigate().back();
	Thread.sleep(3000);
	driver.findElement(By.xpath("(//span[text()='Selenium'])[1]")).click();
	Thread.sleep(3000);
	String URL2=driver.getCurrentUrl();
	System.out.println(URL2);
	Thread.sleep(10000);
	driver.close();
		

	}

}
