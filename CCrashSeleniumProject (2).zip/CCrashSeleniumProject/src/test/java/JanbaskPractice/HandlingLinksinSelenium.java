package JanbaskPractice;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingLinksinSelenium {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com/");
	WebElement ele=	driver.findElement(By.xpath("//a[text()='Gmail']"));
	String UrlValue=ele.getText();
	System.out.println(UrlValue);
	if(ele.isDisplayed()==true && ele.isEnabled()==true)
	{
		ele.click();
	}
	
	
	
		

	}

}
