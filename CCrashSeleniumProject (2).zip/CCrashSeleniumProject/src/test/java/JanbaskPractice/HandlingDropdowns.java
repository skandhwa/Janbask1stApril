package JanbaskPractice;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class HandlingDropdowns {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.tutorialspoint.com/selenium/practice/selenium_automation_practice.php");
		
	WebElement ele=	driver.findElement(By.xpath("//select[@id='state']"));
	Select oselect=new Select(ele);
	
	//oselect.selectByIndex(2);
	//oselect.selectByVisibleText("Haryana");
	oselect.selectByIndex(3);
	
	
	List<WebElement> li=oselect.getOptions();
	
	System.out.println(li.size());
		
		
		
		
		
		

	}

}
