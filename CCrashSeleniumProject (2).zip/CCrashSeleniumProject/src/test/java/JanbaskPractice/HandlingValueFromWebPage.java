package JanbaskPractice;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingValueFromWebPage {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demoqa.com/automation-practice-form");
		driver.manage().window().maximize();
	WebElement ele=	driver.findElement(By.xpath("//label[@id='userName-label']"));
	String Username=ele.getText();	
	System.out.println(Username);
	

	}

}
