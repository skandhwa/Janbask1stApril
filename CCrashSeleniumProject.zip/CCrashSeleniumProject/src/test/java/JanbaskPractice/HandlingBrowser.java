package JanbaskPractice;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingBrowser {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Windows.html");
		driver.manage().window().maximize();
		String CurrentTitle=driver.getTitle();
		System.out.println(CurrentTitle);
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("(//button[@class='btn btn-info'])[1]")).click();
	Set<String> S1=	driver.getWindowHandles();
	System.out.println(S1);
	
	
	
	
	Thread.sleep(10000);
	driver.quit();
		

	}

}
