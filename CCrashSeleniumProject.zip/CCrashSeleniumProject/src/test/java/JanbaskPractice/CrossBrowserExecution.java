package JanbaskPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;



public class CrossBrowserExecution {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		
		
		WebDriver driver1=new FirefoxDriver();
//		
		WebDriver driver2=new EdgeDriver();
		
		
		driver.get("https://www.google.com");
       String TitleWebPage= 	driver.getTitle();	
       System.out.println(TitleWebPage);
       
       Assert.assertEquals("Google", TitleWebPage);
       System.out.println("Test case passed");
       

		driver1.get("https://www.google.com");
      String TitleWebPage1= 	driver1.getTitle();	
      System.out.println(TitleWebPage1);
      
      Assert.assertEquals("Google", TitleWebPage1);
      System.out.println("Test case passed");
      
      
      driver2.get("https://www.google.com");
      String TitleWebPage2= 	driver2.getTitle();	
      System.out.println(TitleWebPage2);
      
      Assert.assertEquals("Google", TitleWebPage2);
      System.out.println("Test case passed");

	}

}
