package Constants;

public class constants {
	
	public static final String ExcelPath="E:\\TestData17thApril.xlsx";
	public static final String PropertyFilePath="src\\main\\java\\Constants\\Global.properties";
	
	

}
