package MyPracticeEx;

class SingleTonEx
{
	private static SingleTonEx instance;
	
	private SingleTonEx()
	{
		System.out.println("Instance created of class");
	}
	
	public static SingleTonEx getInstance()
	{
		if(instance==null)
		{
			instance=new SingleTonEx();
		}
		
		return instance;
	}
	


public void test()
{
	System.out.println("I am singleton method");
}

}

public class SingleTonEx2 {

	public static void main(String[] args) {
	
		SingleTonEx.getInstance().test();
		

	}

}
