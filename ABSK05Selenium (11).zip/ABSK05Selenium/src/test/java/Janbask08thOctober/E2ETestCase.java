package Janbask08thOctober;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class E2ETestCase {

	public static void main(String[] args) throws InterruptedException {
		
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com/");
		driver.manage().window().maximize();
		driver.get("https://demo.guru99.com/V4/index.php");
WebElement ele=		driver.findElement(By.xpath("//input[@name='uid']"));
ele.sendKeys("mngr587535");

WebElement ele2=	driver.findElement(By.xpath("//input[@name='password']"));
ele2.sendKeys("Adyhaze");

WebElement ele3=driver.findElement(By.xpath("//input[@name='btnLogin']"));
Thread.sleep(3000);
ele3.click();










	}

}
