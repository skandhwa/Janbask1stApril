package Janbask08thOctober;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class MySecondTest {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.tutorialspoint.com/selenium/practice/selenium_automation_practice.php");
		driver.manage().window().maximize();
	String Title=	driver.getTitle();
	System.out.println("The title of Web page is  "+Title);
	
String Title2=	driver.getPageSource();

System.out.println("The pagesource of page is  "+Title2);
	
String Current_URL=		driver.getCurrentUrl();
System.out.println("The current URL of page is  "+Current_URL);

driver.navigate().to("https://demoqa.com/automation-practice-form");

		
		
		
		

	}

}
