package Janbask08thOctober;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class HandlingRadioButton {

	public static void main(String[] args) {
		
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.tutorialspoint.com/selenium/practice/selenium_automation_practice.php");
		driver.manage().window().maximize();
WebElement ele=		driver.findElement(By.xpath("//input[@id='gender']"));

if(ele.isEnabled()==true && ele.isDisplayed()==true)
{
	ele.click();
}


WebElement ele2=driver.findElement(By.xpath("//select[@id='state']"));

Select x=new Select(ele2);
x.selectByIndex(3);


WebElement ele3=driver.findElement(By.xpath("(//input[@id='hobbies'])[1]"));
WebElement ele4=driver.findElement(By.xpath("(//input[@type='checkbox'])[2]"));
WebElement ele5=driver.findElement(By.xpath("(//input[@type='checkbox'])[3]"));

//if(ele3.isDisplayed()==true && ele3.isEnabled()==true)
//{
	ele3.click();
	ele4.click();
	ele5.click();
//}




	}

}
