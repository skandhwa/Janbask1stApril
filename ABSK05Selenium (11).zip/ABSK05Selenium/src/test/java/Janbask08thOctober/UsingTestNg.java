package Janbask08thOctober;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;



public class UsingTestNg {
	
	@Test(priority=2)
	public void assertions()
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com");
	String title=	driver.getTitle();
	String Actual_title="Google";
	
	Assert.assertEquals(Actual_title, title);
	
	
	
		
	}
	
	@Test(priority=1)
	public void assertions2()
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.yahoo.com");
	String title=	driver.getTitle();
	String Actual_title="Yahoo | Mail, Weather, Search, Politics, News, Finance, Sports & Videos";
	
	Assert.assertEquals(Actual_title, title);
	}
	

}
