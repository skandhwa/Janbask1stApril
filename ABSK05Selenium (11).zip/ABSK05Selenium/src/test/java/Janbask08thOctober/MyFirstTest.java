package Janbask08thOctober;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class MyFirstTest {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		
		driver.get("https://demoqa.com/automation-practice-form");
		driver.manage().window().maximize();
		
	String Label_value=	driver.findElement(By.xpath("//label[@id='userName-label']")).getText();
		
	System.out.println("The label value is "+Label_value);
	
		
	String WindowID=	driver.getWindowHandle();
	System.out.println("The window id is "+WindowID);
		
		
		
        WebElement ele=driver.findElement(By.xpath("//input[@id='firstName']"));
      boolean flag=  ele.isEnabled();
      System.out.println("Is the textbox enabled "+flag);
        
        
        
		ele.sendKeys("Saurabh");
		Thread.sleep(3000);
		ele.clear();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='gender-radio-1']")).click();

	}

}
