package Janbask08thOctober;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class MYTestCase2 {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.techlistic.com/p/selenium-practice-form.html");
		driver.manage().window().maximize();
		Thread.sleep(3000);
	String Title=	driver.getTitle();
	System.out.println("The title of webpage is "+Title);
	
WebElement ele=	driver.findElement(By.xpath("//input[@name='firstname']"));

boolean y =ele.isEnabled();

System.out.println("Is the text box enabled "+y);

	
ele.sendKeys("Saurabh");

WebElement ele2=driver.findElement(By.xpath("//input[@name='lastname']"));
ele2.sendKeys("Kandhway");

String WindowID=driver.getWindowHandle();

System.out.println("The Window ID is "+WindowID);

driver.navigate().back();

driver.navigate().forward();

driver.navigate().refresh();

Thread.sleep(5000);

driver.close();





	
	
	
	
	
	
		
		
		
		
		
		
		

	}

}
