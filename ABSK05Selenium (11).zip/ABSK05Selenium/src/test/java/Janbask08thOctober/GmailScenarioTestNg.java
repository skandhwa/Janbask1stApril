package Janbask08thOctober;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class GmailScenarioTestNg {
	
	@Test
	public void login()
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com/");
		driver.manage().window().maximize();
	String title=	driver.getTitle();
	System.out.println("The title of page is "+title);
WebElement ele=		driver.findElement(By.xpath("//a[text()='Gmail']"));
if(ele.isDisplayed()==true && ele.isEnabled()==true)
{
	ele.click();
}

String title2=	driver.getTitle();
System.out.println("The title of page is "+title2);

driver.navigate().back();

String title3=	driver.getTitle();
System.out.println("The title of page is "+title3);


if(title.equalsIgnoreCase(title3))
{
	System.out.println("Both title are matched");
}

	}
	
	

}
