package Janbask08thOctober;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingWindows {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Windows.html");
	String WindowID=	driver.getWindowHandle();
	
	System.out.println("The Window ID is "+WindowID);
	
WebElement ele=	driver.findElement(By.xpath("//button[@class='btn btn-info']"));
	
		if(ele.isDisplayed()==true && ele.isEnabled()==true)
		{
			ele.click();
		}
		
		Set<String> WindowsID=driver.getWindowHandles();
		
		System.out.println("The Windows ID are   "+WindowsID);
		
		
		
		

	}

}
