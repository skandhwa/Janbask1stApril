package Janbask08thOctober;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class TestNgCreateTest {
	
	@Test
	
	public void myTc1() throws InterruptedException
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.tutorialspoint.com/selenium/practice/selenium_automation_practice.php");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//input[@id='name']")).sendKeys("Saurabh");
		driver.findElement(By.xpath("//input[@id='gender']")).click();
		driver.findElement(By.xpath("//input[@id='mobile']")).sendKeys("99999999");
		driver.findElement(By.xpath("//input[@id='dob']")).sendKeys("04-11-1993");
		driver.findElement(By.xpath("//input[@id='subjects']")).sendKeys("Maths");
		Thread.sleep(5000);
	WebElement ele2=	driver.findElement(By.xpath("//input[@id='picture']"));
		ele2.sendKeys("C:\\Users\\saura\\OneDrive\\Pictures\\133616763704692637.jpg");
		
	}

}
