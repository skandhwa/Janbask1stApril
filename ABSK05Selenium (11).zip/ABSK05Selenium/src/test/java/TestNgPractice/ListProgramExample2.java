package TestNgPractice;

import java.util.ArrayList;
import java.util.List;

public class ListProgramExample2 {

	public static void main(String[] args) {
		
		List<String> li=new ArrayList<String>();
		li.add("My");
		li.add("Name is");
		li.add("Saurabh");
		
		int x=li.size();
		
		System.out.println(x);
		
		
		Object[] a=li.toArray();
		
		
		for(Object y:a)
		{
			System.out.println(y);
		}
		
	int z=	a.length;
	
	System.out.println(z);
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
