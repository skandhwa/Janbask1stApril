package TestNgPractice;

import org.testng.annotations.Test;

public class UsingDependsOn {
	
	@Test
	public void SignIn()
	{
		System.out.println("I am signIn method");
		int x=9/0;
		System.out.println(x);
	}
	
	
	@Test(dependsOnMethods= {"SignIn"})
	public void searchProduct()
	{
		System.out.println("Search product functionality");
	}
	
	

}
