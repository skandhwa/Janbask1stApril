package TestNgPractice;

import org.testng.annotations.Test;

public class TestNgPriorityEx {
	
	@Test(priority=0)
	public void B()
	{
		System.out.println("Hello");
	}
	
	@Test
	public void A()
	{
		System.out.println("Hello1");
	}
	
	

}
