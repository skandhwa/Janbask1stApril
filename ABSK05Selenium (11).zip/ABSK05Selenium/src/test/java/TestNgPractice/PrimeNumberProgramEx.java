package TestNgPractice;

public class PrimeNumberProgramEx {
	
	
	public static void checkPrime(int n)
	{
		
		int m=n/2;
		boolean flag=false;
		
		
		
		
		if(n==0|| n==1)
		{
			System.out.println("Not a prime number");
			
		}
		
		else
		{
			for(int i=2;i<=m;i++)
			{
				if(n%i==0)
				{
					System.out.println("Not a prime number");
					flag=true;
					break;
				}
				
				if(flag==false)
				{
					System.out.println(" prime number");
					break;
				}
			}
		}
	}
	

	public static void main(String[] args) {
		
		
		for(int i=0;i<=100;i++)
		{
			checkPrime(i);
			
			System.out.println(i+"  ");
		}
		
		
		
		
		
		
		
		
	}

}
