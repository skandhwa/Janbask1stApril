package TestNgPractice;

import java.util.ArrayList;
import java.util.List;

public class ListExample3 {

	public static void main(String[] args) {
		
		List<String> li=new ArrayList<String>();
		li.add("My");
		li.add("Name is");
		li.add("Saurabh");
		
		
		

	}

}
