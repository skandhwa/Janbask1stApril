package TestNgPractice;

class InvalidAgeException extends Exception 
{
	public InvalidAgeException(String message)
	{
		super(message);
	}
}


class CustomExceptionSelf 
{
	public static void validateage(int age ) throws InvalidAgeException
	{
		if(age<18)
		{
			throw new InvalidAgeException("Age is not valid");
		}
		else
		{
			System.out.println("Age is perfect");
		}
	}
}
public class CustomeExceptionNew {

	public static void main(String[] args) throws InvalidAgeException {
		
		CustomExceptionSelf.validateage(12);
		

	}

}
