package TestNgPractice;

public class SecondOccurenceNew {

	public static void main(String[] args) {
		
		int []a= {1, 2, 2, 5, 7, 9, 9, 3, 1,7,8,9,5,1};
		int count =0;
		
		for(int i=0;i<a.length;i++)
		{
			if(a[i]==1)
			
				count++;
			
			
			if(count==3)
			{
				System.out.println("Element occured at location "+i);
				break;
			}
			
		}
		

	}

}
