package TestNgPractice;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class TestNgParametersEx {
	
	@Test
	@Parameters({"a","b","c"})
	public void sum(int x,int y,int z)
	{
		int r=x+y+z;
		System.out.println(r);
	}
	
	
	@Test
	@Parameters({"a","b","c"})
	public void multiply(int x,int y,int z)
	{
		int r=x*y*z;
		System.out.println(r);
	}
	
	
	

}
