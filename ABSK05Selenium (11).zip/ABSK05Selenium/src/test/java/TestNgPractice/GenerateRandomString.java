package TestNgPractice;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class GenerateRandomString {

	public static void main(String[] args) {
		
		String str="ABCDEFabcdefijklmnopqrst";
		System.out.println("Enter a string of length n");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		
		char []s1=str.toCharArray();
		
		List<Character> li=new ArrayList<Character>();
		StringBuilder sb=new StringBuilder();
		for(Character x:s1)
		{
			li.add(x);
		}
		
		int x=li.size();
		
		Collections.shuffle(li);
		
		for(int i=0;i<n;i++)
		{
			sb.append(li.get(i%x));
		}
		
		System.out.println(sb.toString());
		
		
		
		

	}

}
