package TestNgPractice;

import org.testng.annotations.Test;

public class UsingTestNgGroups2 {
	
	@Test(groups= {"regression"},priority=2)
	public void start2()
	{
		
		//System.out.println("Hello Hi I am second class");
		int x=9/0;
		System.out.println(x);
	}
	
	@Test(groups= {"regression"},priority=-3)
	public void start3()
	{
		
		System.out.println("Hello Hi I am class number 3");
	}
	
	@Test(groups= {"regression"},priority=0)
	public void start4()
	{
		
		System.out.println("Hello Hi I am fourth class");
	}
	
	
	@Test(dependsOnGroups = {"regression"},priority=5)
	public void display()
	{
		System.out.println("hello");
	}
	

}
