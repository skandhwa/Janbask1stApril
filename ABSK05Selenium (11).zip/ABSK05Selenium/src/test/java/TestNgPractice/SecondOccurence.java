package TestNgPractice;

import java.util.Arrays;
import java.util.List;

public class SecondOccurence {

	public static void main(String[] args) {
		
		int []a= {1,2,2,5,7,9,1,3,5};
		
		List li=Arrays.asList(a);
		
	int x=	li.indexOf(1);
	
	List y=li.subList(1, x+1);
	
	System.out.println(y);
		
	      
		

	}

}
