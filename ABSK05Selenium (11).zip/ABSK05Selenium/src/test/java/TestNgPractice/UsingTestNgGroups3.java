package TestNgPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;



public class UsingTestNgGroups3 {
	
	public WebDriver driver;
	String title;
	
	@Test(groups= {"sanity1"})
	public void openBrowser()
	{
		driver=new ChromeDriver();
		driver.get("https://www.google.com");
		title=driver.getTitle();
		System.out.println(title);
	}
	
	@Test(groups= {"sanity2"})
	public void checkTitle()
	{
		System.out.println("Hello");
	}
	
	@Test(groups= {"sanity3"})
	public void closeDriver() throws InterruptedException
	{
		System.out.println("Hi");
	}
	
	
	
	
	

}
