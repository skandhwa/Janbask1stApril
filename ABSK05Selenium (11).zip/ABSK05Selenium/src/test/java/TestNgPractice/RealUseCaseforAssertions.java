package TestNgPractice;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;



public class RealUseCaseforAssertions {
	
	@Test
	public void checkStaticContent()
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://grotechminds.com/registration/");
		driver.manage().window().maximize();
		String Text=driver.findElement(By.xpath("(//button[@type='submit'])[2]")).getText();
		Assert.assertEquals("Submit", Text);
		Reporter.log("My test case got passed");
		
		
	}
	

}
