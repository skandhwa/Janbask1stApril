package TestNgPractice;

import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners(UsingTestNgListeners.class)
public class ListenersImplementation 
{
	@Test(timeOut=1000)
	public void openGoogle() throws InterruptedException
	{
		DriverInitialization.getDriver().get("https://www.google.com");
		Thread.sleep(5000);
		String title=DriverInitialization.getDriver().getTitle();
		System.out.println(title);
		
	}
	
	
	

}
