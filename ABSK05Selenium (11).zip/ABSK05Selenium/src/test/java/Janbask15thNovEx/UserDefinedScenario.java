package Janbask15thNovEx;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class UserDefinedScenario {
	
	static WebDriver driver;
	
	public static void loginPage() throws InterruptedException
	{
		driver=new ChromeDriver();
		
		driver.get("https://www.google.com");
		driver.manage().window().maximize();
	String Title=	driver.getTitle();
	Thread.sleep(3000);
	System.out.println("The title of page is "+Title);
		
	}
	
	public static void AddUidPassword(String Uname,String password) throws InterruptedException
	{
		driver=new ChromeDriver();
		driver.get("https://demo.guru99.com/V4/index.php");
		Thread.sleep(3000);
		driver.manage().window().maximize();
		 WebElement ele1=     driver.findElement(By.xpath("//input[@name='uid']"));
		 ele1.sendKeys(Uname);
		 
		 WebElement ele2=     driver.findElement(By.xpath("//input[@name='password']"));
		 ele2.sendKeys(password);
		 
	}
	
	
	public static void tcAmazon() throws InterruptedException
	{
		driver=new ChromeDriver();
		driver.get("https://www.amazon.in/");
		Thread.sleep(3000);
		driver.manage().window().maximize();
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("window.scrollBy(0,300)", "");
		driver.findElement(By.xpath("(//span[text()='Shop Now'])[1]")).click();
		
		
	}
	
	
	

	public static void main(String[] args) throws InterruptedException {
		
		UserDefinedScenario.loginPage();
		Thread.sleep(3000);
		UserDefinedScenario.AddUidPassword("mngr605194", "ApAtypA");
		Thread.sleep(3000);
		UserDefinedScenario.tcAmazon();

	}

}
