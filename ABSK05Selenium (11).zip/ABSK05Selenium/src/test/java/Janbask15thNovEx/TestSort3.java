package Janbask15thNovEx;

import java.util.*;  
import java.io.*;  
class Student implements Comparable<Student>{  
float salary;  
String name;  
int age;  
Student(float salary,String name,int age){  
this.salary=salary;  
this.name=name;  
this.age=age;  
}  
public int compareTo(Student st){  
if(salary==st.salary)  
return 0;  
else if(salary>st.salary)  
return 1;  
else  
return -1;  
}  
}  
//Creating a test class to sort the elements  
public class TestSort3{  
public static void main(String args[]){  
ArrayList<Student> al=new ArrayList<Student>();  
al.add(new Student(89000f,"Vijay",23));  
al.add(new Student(76000f,"Ajay",27));  
al.add(new Student(42000f,"Jai",21));  
al.add(new Student(34000f,"Harsh",14)); 
al.add(new Student(66000f,"Manish",16)); 
  
Collections.sort(al); 
Collections.reverse(al);
for(Student st:al){  
System.out.println(st.salary+" "+st.name+" "+st.age);  
}  
}  
}  