package Janbask15thNovEx;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestCase2 {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://demo.guru99.com/V4/index.php");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@name='uid']")).sendKeys("mngr605196");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys("ApAtypA");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@name='btnLogin']")).click();
		Thread.sleep(3000);
		driver.switchTo().alert().accept();
		Thread.sleep(3000);
		driver.navigate().refresh();
		driver.findElement(By.xpath("//input[@name='uid']")).sendKeys("mngr605194");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys("ApAtypA");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@name='btnLogin']")).click();
		Thread.sleep(3000);
	String Title=	driver.getTitle();
	
	System.out.println("Title of page is  "+Title);
		
		
		

	}

}
