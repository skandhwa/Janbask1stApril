package Janbask15thNovEx;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class E2EinFirefox {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver =new EdgeDriver();
        driver.get("https://demo.guru99.com/V4/index.php");
        driver.manage().window().maximize();
   WebElement ele1=     driver.findElement(By.xpath("//input[@name='uid']"));
   if(ele1.isDisplayed()==true && ele1.isEnabled()==true)
	   
   {
	   ele1.sendKeys("mngr605193");
   }
   
   WebElement ele2=     driver.findElement(By.xpath("//input[@name='password']"));
   if(ele2.isDisplayed()==true && ele2.isEnabled()==true)
	   
   {
	   ele2.sendKeys("ApAtyqB");
   }
   
   WebElement ele3=     driver.findElement(By.xpath("//input[@name='btnLogin']"));
   if(ele3.isDisplayed()==true && ele3.isEnabled()==true)
	   
   {
	   ele3.click();
   }
   
   Thread.sleep(4000);
   driver.switchTo().alert().accept();
   Thread.sleep(4000);
   driver.navigate().refresh();
   Thread.sleep(4000);
   WebElement ele4=     driver.findElement(By.xpath("//input[@name='uid']")); 
 if(ele4.isDisplayed()==true && ele4.isEnabled()==true)
	   
   {
	   ele4.sendKeys("mngr605194");
   }
 
 WebElement ele5=     driver.findElement(By.xpath("//input[@name='password']"));
 if(ele5.isDisplayed()==true && ele5.isEnabled()==true)
	   
 {
	   ele5.sendKeys("ApAtypA");
 }
   
 WebElement ele6=     driver.findElement(By.xpath("//input[@name='btnLogin']"));
 if(ele6.isDisplayed()==true && ele6.isEnabled()==true)
	   
 {
	   ele6.click();
 }
 
 String URL=driver.getCurrentUrl();
 System.out.println("The Current URL is  "+URL);
 
 
 String title=driver.getTitle();
 System.out.println("The Title is  "+title);	
 
 if(title.contains("Guru99"))
 {
	 System.out.println("Test case passed ");
 }
 
 else
 {
	 System.out.println("Test case failed");
 }
 Thread.sleep(4000);
 JavascriptExecutor js=(JavascriptExecutor)driver;
 js.executeScript("window.scrollBy(0,1000)","");
 Thread.sleep(4000);
 WebElement ele7=driver.findElement(By.xpath("//a[text()='Log out']"));
 
 if(ele7.isDisplayed()==true && ele7.isEnabled()==true)
 {
	 ele7.click();
 }
 Thread.sleep(4000);
 driver.switchTo().alert().accept();
 Thread.sleep(4000);
 
 driver.navigate().refresh();

 Thread.sleep(4000);
 
 driver.quit();
	}

}
