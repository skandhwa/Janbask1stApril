package Janbask15thNovEx;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class CreateTestCase1 {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.wikipedia.org/");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='searchInput']")).sendKeys("Selenium(software)");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("(//span[text()='Selenium'])[1]")).click();
		Thread.sleep(3000);
	String URL=	driver.getCurrentUrl();
	System.out.println("The Current URL is "+URL);
	driver.findElement(By.xpath("(//a[@href='https://selenium.dev/'])[1]")).click();
	Thread.sleep(3000);
	
String URL1=	driver.getCurrentUrl();
	
System.out.println("The Current URL is "+URL1);
	
		
		

	}

}
