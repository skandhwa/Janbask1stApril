package Janbask15thNovEx;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

class Employee
{
	int id;
	String name;
	float salary;
	public Employee (float salary, String name ,int id)
	{
		this.id=id;
		this.name=name;
		this.salary=salary;
	}
	
}

class SalaryComparator implements Comparator<Employee>
{
	public int compare(Employee e1,Employee e2)
	{
		if(e1.salary==e2.salary)
		{
			return 0;
		}
		else if(e1.salary>e2.salary)
		{
			return 1;
		}
		else
			return -1;
	}
}




public class UsingJava8Comparator {

	public static void main(String[] args) {
		
		List<Employee> al=new ArrayList<Employee>();
		al.add(new Employee(89000f,"Vijay",23));  
		al.add(new Employee(76000f,"Ajay",27));  
		al.add(new Employee(42000f,"Jai",21));  
		al.add(new Employee(34000f,"Harsh",14)); 
		al.add(new Employee(66000f,"Manish",16)); 
		
		al.stream().sorted().forEach(System.out::println);
		
		for(Employee x:al)
		{
			System.out.println(x.name+"  "+x.salary+" "+x.id);
		}
		
		

	}

}
