package Janbask15thNovEx;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class NegativeTestCase {

	public static void main(String[] args) throws InterruptedException {
		
		
		
		WebDriver driver=new EdgeDriver();
		driver.get("https://www.google.com");
		 
		 
		 
		 
		 

	}

}
