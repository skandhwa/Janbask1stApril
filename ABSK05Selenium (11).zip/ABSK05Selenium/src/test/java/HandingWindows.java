import java.util.Set;

import javax.swing.text.html.HTMLDocument.Iterator;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandingWindows {
	

	public static void main(String[] args) {
		
     WebDriver driver=new ChromeDriver();
     driver.get("");
     String windowID=driver.getWindowHandle();
     
     driver.findElement(By.xpath("X")).click();
     Set<String> WindowsID=driver.getWindowHandles();
     
     for(String x:WindowsID)
     {
     Iterator itr=x.iterator();
     }
     
     while(itr.hasNext())
     {
    	 
    	 
     }
     
     
     
     
     
     
     
     
     
     
		
		
	}

}
