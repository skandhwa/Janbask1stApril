package AdvanceSelenium;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class ArraytoArrayListConversion {

	public static void main(String[] args) {
		
		int []a= {2,5,6,1,9,8,14};
		
		List<Integer> li=new ArrayList<Integer>();
		
		for(Integer x:a)
		{
			li.add(x);
		}
		
		Collections.sort(li);
		Collections.reverse(li);
		
	System.out.println(li.get(0));	
	System.out.println(li.get(1));	
		

	}

}
