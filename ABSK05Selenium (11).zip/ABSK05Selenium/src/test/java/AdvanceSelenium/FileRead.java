package AdvanceSelenium;

import java.io.FileReader;
import java.io.IOException;

public class FileRead {

	public static void main(String[] args) throws IOException {
		
		FileReader f=new FileReader("‪E:\\NewMan Reports.txt");
		int i;
		
		while((i=f.read())!=-1) 
		{
			System.out.println((char)i);
		}
		
		

	}

}
