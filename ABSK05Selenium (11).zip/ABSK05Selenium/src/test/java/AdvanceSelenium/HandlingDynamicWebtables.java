package AdvanceSelenium;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingDynamicWebtables {

	public static void main(String[] args) {
		
		WebDriver driver= new ChromeDriver();
		driver.get("file:///C://Users//saura//Downloads//WebTable.html");
		driver.manage().window().maximize();
		
		String beforeXpath="//table/tbody/tr[";
		String afterXpath="]/td[2]";
List<WebElement> rows=driver.findElements(By.xpath("//table/tbody/tr"));
int x=rows.size();
System.out.println("Total Number of rows are "+x);

System.out.println("List of all names in the tabel are");
for(int i=2;i<=x;i++)
{
	String names=driver.findElement(By.xpath(beforeXpath+i+afterXpath)).getText();
	System.out.println(names);
	if(names.contains("Will"))
	{
		String cbx_beforexpath="//table/tbody/tr[";
		String cbx_afterxpath="]/td[1]/input";
	WebElement checkbox=	driver.findElement(By.xpath(cbx_beforexpath+i+cbx_afterxpath));
	checkbox.click();
	System.out.println("candidate has been selected");
	}
	
	
	
	
}




	}

}
