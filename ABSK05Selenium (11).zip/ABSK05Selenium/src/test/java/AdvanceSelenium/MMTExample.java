package AdvanceSelenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class MMTExample {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.flipkart.com/search?q=iphone+15&sid=tyy%2C4io&as=on&as-show=on&otracker=AS_QueryStore_OrganicAutoSuggest_3_1_na_na_na&otracker1=AS_QueryStore_OrganicAutoSuggest_3_1_na_na_na&as-pos=3&as-type=HISTORY&suggestionId=iphone+15%7CMobiles&requestId=aada9ade-f809-4412-b2d1-b935d5e23e5d");
	String Value=	driver.findElement(By.xpath("//*[text()='Apple iPhone 15 (Pink, 128 GB)']//following::div[7]")).getText();
		System.out.println(Value);
		
		
		
		
		

	}

}
