package JanbaskPractice;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class NavigationCommands {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new EdgeDriver();
		driver.get("https://www.google.com/");
		driver.manage().window().maximize();
	String Title=	driver.getTitle();
	
String WindowHandle=	driver.getWindowHandle();
System.out.println("Window ID is  "+WindowHandle);

driver.findElement(By.xpath("//textarea[@class='gLFyf']")).sendKeys("Java Selenium");
driver.findElement(By.xpath("//input[@value='Google Search']")).click();


	
	
	System.out.println("The title of page is "+Title);
	driver.navigate().back();
     Thread.sleep(3000);
     
     driver.navigate().back();
     Thread.sleep(3000);
     driver.navigate().forward();
     Thread.sleep(3000);
     driver.navigate().refresh();
     driver.close();
     
     
	
		

	}

}
