package JanbaskPractice;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TextValidationEx {

	public static void main(String[] args) {
		
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demoqa.com/automation-practice-form");
		driver.manage().window().maximize();
	String Text=	driver.findElement(By.xpath("//label[@id='userName-label']")).getText();
System.out.println("The text value is "+Text);
	
	
	}

}
