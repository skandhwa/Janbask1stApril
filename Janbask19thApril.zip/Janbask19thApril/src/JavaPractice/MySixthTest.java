package JavaPractice;

public class MySixthTest {

	public static void main(String[] args) {
	
		
		MyFifthTest obj=new MyFifthTest();
		obj.display5();
		

	}

}
