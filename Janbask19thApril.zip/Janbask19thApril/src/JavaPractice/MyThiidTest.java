package JavaPractice;

public class MyThiidTest {
	
	void message()
	{
		System.out.println("How r u");
	}
	

	public static void main(String[] args) {
		
		MyThiidTest object=new MyThiidTest();
		object.message();
		
		

	}

}
