package JavaPractice;

import java.util.ArrayList;
import java.util.List;

public class MyFirstTest {
	
	public static void main()
	{
		
	}

	public static void main(String[] args) {
		
	/*	System.out.println("This is my java Program");
		System.out.println("This is my first code");
		System.out.println("Java is robust"); */
		
		int x=10;
		
		List<Integer> li=new ArrayList<Integer>();
		
		if(x<5)
		
			System.out.println("Test case pass");
			
		
		
		else
		
			System.out.println("Test case fail");
		
		
		
		
		
		
		

	}

}
