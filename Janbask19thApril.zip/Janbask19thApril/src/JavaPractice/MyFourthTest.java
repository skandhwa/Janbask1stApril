package JavaPractice;

public class MyFourthTest {

	public static void main(String[] args) {
		
		int x=10,y=20,z=30;
		float a=10.55f ,b=55.56f;
		
		double c=2132132132132.123123121232;
		
		int m=1213213221;
		long q=2132121321321312L;
		
		boolean h=true;
		
		
		
		

	}

}
