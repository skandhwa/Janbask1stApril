package JavaPractice2;

import JavaPractice.MyFifthTest;

public class Mylatest {

	public static void main(String[] args) {
		
		
		MyFifthTest obj=new MyFifthTest();
		obj.display5();

	}

}
