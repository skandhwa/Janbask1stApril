package LoopingConcepts;

public class ifLoopRealTime {

	public static void main(String[] args) {
		

	}

}
