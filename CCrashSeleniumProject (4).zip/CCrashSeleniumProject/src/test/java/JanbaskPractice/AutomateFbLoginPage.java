package JanbaskPractice;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class AutomateFbLoginPage {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.facebook.com/");
		driver.manage().window().maximize();
		
	boolean flag=	driver.findElement(By.id("email")).isDisplayed();
	System.out.println(flag);
		
		
		driver.findElement(By.id("email")).sendKeys("abcd@gmail.com");
		Thread.sleep(5000);
		driver.findElement(By.id("email")).clear();
		
//		driver.findElement(By.id("pass")).sendKeys("test@1234");
//		driver.findElement(By.name("login")).click();
		
		
		
		
		

	}

}
