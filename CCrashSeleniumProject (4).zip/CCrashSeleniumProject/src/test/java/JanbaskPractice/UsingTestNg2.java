package JanbaskPractice;

import org.testng.annotations.Test;

public class UsingTestNg2 {
	
	@Test
	public void login()
	{
		System.out.println("Login to application");
		
	}
	
	
	@Test(dependsOnMethods= {"login"})
	public void SearchProduct()
	{
		System.out.println("SearchProduct in application");
		
	}
	
	@Test(dependsOnMethods= {"login","SearchProduct"})
	public void AddtoCart()
	{
		System.out.println("AddtoCart in application");
		int x=9/0;
		System.out.println(x);
		
	}
	
	
	@Test(dependsOnMethods= {"login","SearchProduct","AddtoCart"},alwaysRun=true)
	public void PaymentGateway()
	{
		System.out.println("PaymentGateway in application");
		
	}
	
	
	

}
