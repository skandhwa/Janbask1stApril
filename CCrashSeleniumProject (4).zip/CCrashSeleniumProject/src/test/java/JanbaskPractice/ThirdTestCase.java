package JanbaskPractice;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ThirdTestCase {

	public static void main(String[] args) {
		
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.facebook.com/");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("ASASASSASASASDEDD");
		driver.findElement(By.xpath("//input[@id='pass']")).sendKeys("@@EADDDDE#E#");
		driver.findElement(By.xpath("//button[@name='login']")).click();
	String Text=	driver.findElement(By.xpath("//div[@class='_9ay7']")).getText();

	System.out.println(Text);
	}

}
