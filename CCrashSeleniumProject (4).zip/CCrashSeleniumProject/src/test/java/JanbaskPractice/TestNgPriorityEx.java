package JanbaskPractice;

import org.testng.annotations.Test;

public class TestNgPriorityEx {
	
	@Test(priority=6)
	public void display()
	{
		System.out.println("Hello how are you");//5
	}
	
	@Test(priority=-4)
	public void display1()
	{
		System.out.println("Hello how are you 1");//1
	}
	
	
	@Test(priority=0)
	public void display2()
	{
		System.out.println("Hello how are you 2");//2
	}
	
	@Test(priority=3)
	public void A()
	{
		System.out.println("Hello how are you A");//3
	}
	
	@Test(priority=3)
	public void B()
	{
		System.out.println("Hello how are you B");//4
	}
	

}
