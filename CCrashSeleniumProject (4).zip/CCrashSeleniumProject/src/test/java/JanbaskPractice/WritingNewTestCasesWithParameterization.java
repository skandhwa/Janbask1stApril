package JanbaskPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class WritingNewTestCasesWithParameterization {
	
	public static void OpenPageInChrome() throws InterruptedException
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com");
		Thread.sleep(7000);
		driver.close();
	}
	
	public static void OpenPageInFirefox() throws InterruptedException
	{
		WebDriver driver=new FirefoxDriver();
		driver.get("https://www.google.com");
		Thread.sleep(7000);
		driver.close();
	}
	
	public static void OpenPageInEdge() throws InterruptedException
	{
		WebDriver driver=new EdgeDriver();
		driver.get("https://www.google.com");
		Thread.sleep(7000);
		driver.close();
	}
	
	public static void main(String[] args) throws InterruptedException {
		
		WritingNewTestCasesWithParameterization.OpenPageInChrome();
		WritingNewTestCasesWithParameterization.OpenPageInFirefox();
		WritingNewTestCasesWithParameterization.OpenPageInEdge();
		
		

	}

}
