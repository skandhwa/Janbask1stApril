package JanbaskPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class UsingTestNg1 {
	
	@Test(priority=2,enabled=false)
	public void sum()
	{
		System.out.println("Hello");
	}
	
	
	@Test(priority=1)
	public void display()
	{
		System.out.println("Hi");
	}
	
	@Test(priority=-2)
	public void getTitle()
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com");
		String Title=driver.getTitle();
		System.out.println(Title);
	}
	
	
	

}
