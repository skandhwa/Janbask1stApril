package JanbaskPractice;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WritingTestCaseWithParameterization {
	public static WebDriver driver;
	
	public static void LoginApplication(String UName,String Password)
	{
		 driver=new ChromeDriver();
		driver.get("https://demo.guru99.com/V4/index.php");
		driver.findElement(By.xpath("//input[@name='uid']")).sendKeys(UName);
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys(Password);
		driver.findElement(By.xpath("//input[@name='btnLogin']")).click();
	}
	
	public static void ClickOnCustomerLink()
	{
		driver.findElement(By.xpath("//a[text()='New Customer']")).click();
	}
	
	
	

	public static void main(String[] args) {
		
		WritingTestCaseWithParameterization.LoginApplication("mngr572285", "AjAnYgt");
		WritingTestCaseWithParameterization.ClickOnCustomerLink();
		
		
		

	}

}
