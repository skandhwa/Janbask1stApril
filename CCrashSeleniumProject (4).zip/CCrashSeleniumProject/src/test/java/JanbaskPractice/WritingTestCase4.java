package JanbaskPractice;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WritingTestCase4 {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.guru99.com/V4/index.php");
		driver.manage().window().maximize();
		Thread.sleep(3000);
		
	WebElement ele=	driver.findElement(By.xpath("//input[@name='uid']"));
	WebElement ele2=	driver.findElement(By.xpath("//input[@type='password']"));
	
	if(ele.isDisplayed()==true && ele.isEnabled()==true)
	{
		ele.sendKeys("mngr572276");
	}
	
	Thread.sleep(3000);
	
	if(ele2.isDisplayed()==true && ele2.isEnabled()==true)
	{
		ele2.sendKeys("AjAnYza");
	}
	
WebElement ele3=	driver.findElement(By.xpath("//input[@type='submit']"));

if(ele3.isDisplayed()==true && ele3.isEnabled()==true)
{
	ele3.click();
}

String Title=driver.getCurrentUrl();
System.out.println(Title);
if(Title.contains("homepage")==true)
{
	System.out.println("My scenario is passed");
}


Thread.sleep(3000);

WebElement ele4=driver.findElement(By.xpath("//a[text()='Log out']"));

if(ele4.isDisplayed()==true && ele4.isEnabled()==true)
{
	ele4.click();
}

Thread.sleep(3000);

driver.switchTo().alert().accept();

Thread.sleep(6000);


String  Title2= driver.getCurrentUrl();
System.out.println(Title2);

if(Title2.contains("index.php")==true)
{
	System.out.println("My scenario is passed");
}
	
		
		

	}

}
