package JanbaskPractice;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class UserDefinedMethodsForSelenium {
	
	public static void WriteTest(String TypeofDevice)
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.amazon.in/");
		driver.manage().window().maximize();
		String Title=driver.getTitle();
		System.out.println(Title);
		driver.findElement(By.xpath("//input[@id='twotabsearchtextbox']")).sendKeys(TypeofDevice);
	}
	
	public static void WriteTest2()
	{
		WebDriver driver1=new FirefoxDriver();
		driver1.get("https://www.flipkart.com/");
		String Title1=driver1.getTitle();
		System.out.println(Title1);
	}


	public static void main(String[] args) {
		
		UserDefinedMethodsForSelenium.WriteTest("Mobile Phones");
		UserDefinedMethodsForSelenium.WriteTest2();
		
		

	}

}
