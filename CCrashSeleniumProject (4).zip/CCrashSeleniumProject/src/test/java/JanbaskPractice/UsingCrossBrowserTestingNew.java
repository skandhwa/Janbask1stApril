package JanbaskPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class UsingCrossBrowserTestingNew {
	
	public static WebDriver driver;
	public static String BrowserName;

	public static void main(String[] args) throws InterruptedException {
		
		for(int browser=1;browser<=3;browser++)
		{
			if(browser==1)
			{
				driver=new ChromeDriver();
				BrowserName="GoogleChrome";
				
			}
			
			else if(browser==2)
			{
				driver=new FirefoxDriver();
				BrowserName="MozillaFirefox";
			}
			
			else if(browser==3)
			{
				driver=new EdgeDriver();
				BrowserName="InternetEdge";
			}
		}
		
		
		driver.get("https://www.google.com");
		String title=driver.getTitle();
		System.out.println(title);
		
		if(title.equals("Google"))
		{
			System.out.println("Test Case Passed");
		}
		

		Thread.sleep(7000);
		driver.close();
		
	}
	

	
	

}
