package JanbaskPractice;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class UsingTestNgAnnotations {
	
	@BeforeMethod
	public void prereq()
	{
		System.out.println("pre req methods");
	}
	
	
	@AfterMethod
	public void postreq()
	{
		System.out.println("post req methods");
	}
	
	
	@Test
	public void sum()
	{
		System.out.println("Hello");
	}
	
	
	@Test
	public void display()
	{
		System.out.println("Hi");
	}
	
	

}
