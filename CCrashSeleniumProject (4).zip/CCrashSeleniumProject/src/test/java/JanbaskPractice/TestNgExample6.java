package JanbaskPractice;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

public class TestNgExample6 {
	
	@AfterClass
	public void logout()
	{
		System.out.println("This is logout");
	}
	
	@BeforeSuite
	public void login()
	{
		System.out.println("I am login");
	}
	
	@Test(priority=1)
	public void display()
	{
		System.out.println("This is display1");
	}
	
	@Test(priority=-4)
	public void search()
	{
		System.out.println("This is search");
	}
	
	
	@Test(priority=0)
	public void add()
	{
		System.out.println("This is add");
	}
	
	
	

}
