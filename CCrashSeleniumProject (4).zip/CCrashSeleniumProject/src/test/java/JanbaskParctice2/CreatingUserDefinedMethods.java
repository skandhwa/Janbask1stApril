package JanbaskParctice2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

class Exe1
{
public WebDriver driver;
void login() throws InterruptedException
{
	driver=new ChromeDriver();
	driver.get("https://www.google.com");
	driver.manage().window().maximize();
	String title=driver.getTitle();
	System.out.println(title);
	Thread.sleep(5000);
	driver.close();
}

void checkTitle2() throws InterruptedException
{
	driver=new ChromeDriver();
	driver.get("https://www.flipkart.com");
	driver.manage().window().maximize();
	String title=driver.getTitle();
	System.out.println(title);
	Thread.sleep(5000);
	driver.close();
}

void checkTitle3() throws InterruptedException
{
	driver=new ChromeDriver();
	driver.get("https://www.amazon.com");
	driver.manage().window().maximize();
	String title=driver.getTitle();
	System.out.println(title);
	Thread.sleep(5000);
	driver.close();
}


public void TestValidationGur99(String username,String password) throws InterruptedException
{
	driver=new ChromeDriver();
	driver.get("https://demo.guru99.com/V4/index.php");
	driver.manage().window().maximize();
	driver.findElement(By.xpath("//input[@name='uid']")).sendKeys(username);
	driver.findElement(By.xpath("//input[@name='password']")).sendKeys(password);
	driver.findElement(By.xpath("//input[@name='btnLogin']")).click();
	Thread.sleep(3000);
	driver.switchTo().alert().accept();
	driver.navigate().refresh();
	WebElement ele=driver.findElement(By.xpath("//input[@name='uid']"));
	if(ele.isDisplayed()==true)
	{
	ele.sendKeys(username);
	}
	driver.findElement(By.xpath("//input[@name='password']")).sendKeys(password);
	
	WebElement ele2=driver.findElement(By.xpath("//input[@name='btnLogin']"));
	
	if(ele2.isDisplayed()==true && ele2.isEnabled()==true)
	{
	ele2.click();
	}
String Title=	driver.getTitle();
System.out.println(Title);

if(Title.contains("HomePage"))
{
	System.out.println("Test case passed");
}
else
{
	System.out.println("Test case failed");
}
Thread.sleep(5000);
driver.close();

}





}

public class CreatingUserDefinedMethods {

	public static void main(String[] args) throws InterruptedException {
		
		Exe1 obj=new Exe1();
		obj.login();
		obj.checkTitle2();
		obj.checkTitle3();
		obj.TestValidationGur99("mngr580849", "guqEjrf");
		obj.TestValidationGur99("mngr580849","guqEjed");
		

	}

}
