package JanbaskParctice2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class E2ETestCaseWikipedia {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.wikipedia.org/");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//input[@id='searchInput']")).sendKeys("Selenium(software)");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//div[@class='suggestion-thumbnail']")).click();
		Thread.sleep(5000);
//		driver.findElement(By.xpath("//button[@type='submit']")).click();
		driver.findElement(By.xpath("(//span[text()='Create account'])[1]")).click();
		Thread.sleep(5000);
	String URL=	driver.getCurrentUrl();
	System.out.println(URL);
	
	driver.navigate().back();
	Thread.sleep(5000);
	
	driver.findElement(By.xpath("//a[text()='Official website']")).click();
	Thread.sleep(5000);
	String URL2=driver.getCurrentUrl();
	System.out.println(URL2);
	
	if(URL.contains("wikipedia"))
	{
		System.out.println("Internal URL");
	}
	else
	{
		System.out.println("External URL");
	}
	
	
	if(URL2.contains("wikipedia"))
	{
		System.out.println("Internal URL");
	}
	else
	{
		System.out.println("External URL");
	}
	
	
	
		

	}

}
