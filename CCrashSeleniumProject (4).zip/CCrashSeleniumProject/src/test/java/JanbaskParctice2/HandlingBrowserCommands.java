package JanbaskParctice2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingBrowserCommands {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.techlistic.com/p/selenium-practice-form.html");
	String WindowID=	driver.getWindowHandle();
	System.out.println(WindowID);
	driver.manage().window().maximize();
	
	driver.findElement(By.xpath("//input[@name='firstname']")).sendKeys("Saurabh");
	String Text=driver.findElement(By.xpath("//input[@name='firstname']")).getText();
	System.out.println(Text);
	driver.findElement(By.xpath("//input[@name='lastname']")).sendKeys("Kandhway");
String URL=	driver.getCurrentUrl();	
System.out.println(URL);
String title=driver.getTitle();
System.out.println(title);
driver.findElement(By.xpath("//input[@id='datepicker']")).sendKeys("10/12/2023");


	}

}
