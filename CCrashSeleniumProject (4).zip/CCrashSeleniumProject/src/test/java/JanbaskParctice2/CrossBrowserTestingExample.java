package JanbaskParctice2;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class CrossBrowserTestingExample {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com");
	String Title=	driver.getTitle();
	System.out.println(Title);
	Thread.sleep(5000);
	driver.close();
	
	WebDriver driver2=new FirefoxDriver();
	driver2.get("https://www.google.com");
String Title2=	driver2.getTitle();
System.out.println(Title2);
Thread.sleep(5000);
driver2.close();


WebDriver driver3=new EdgeDriver();
driver3.get("https://www.google.com");
String Title3=	driver3.getTitle();
System.out.println(Title3);
Thread.sleep(5000);
driver3.close();
	
	
	
	

	}

}
