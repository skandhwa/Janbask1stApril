package JanbaskParctice2;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BrowserCommands {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.tutorialspoint.com/selenium/practice/selenium_automation_practice.php");
		driver.manage().window().maximize();
	String Title=	driver.getTitle();
	System.out.println(Title);
	
	String PageSource=driver.getPageSource();
	System.out.println(PageSource);
	
	String CurrentURL=driver.getCurrentUrl();
	System.out.println(CurrentURL);
		

	}

}
