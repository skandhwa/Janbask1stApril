package JanbaskParctice2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class E2ETestCaseLoginGuru99 {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.guru99.com/V4/index.php");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//input[@name='uid']")).sendKeys("mngr580849");
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys("guqEjrf");
		driver.findElement(By.xpath("//input[@name='btnLogin']")).click();
		Thread.sleep(3000);
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		WebElement ele=driver.findElement(By.xpath("//input[@name='uid']"));
		if(ele.isDisplayed()==true)
		{
		ele.sendKeys("mngr580849");
		}
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys("guqEjed");
		
		WebElement ele2=driver.findElement(By.xpath("//input[@name='btnLogin']"));
		
		if(ele2.isDisplayed()==true && ele2.isEnabled()==true)
		{
		ele2.click();
		}
	String Title=	driver.getTitle();
	System.out.println(Title);
	
	if(Title.contains("HomePage"))
	{
		System.out.println("Test case passed");
	}
	else
	{
		System.out.println("Test case failed");
	}
	Thread.sleep(5000);
	driver.close();
	
	WebDriver driver1=new EdgeDriver();
	driver1.get("https://demo.guru99.com/V4/index.php");
	driver1.manage().window().maximize();
	driver1.findElement(By.xpath("//input[@name='uid']")).sendKeys("mngr580849");
	driver1.findElement(By.xpath("//input[@name='password']")).sendKeys("guqEjrf");
	driver1.findElement(By.xpath("//input[@name='btnLogin']")).click();
	Thread.sleep(3000);
	driver1.switchTo().alert().accept();
	driver1.navigate().refresh();
	driver1.findElement(By.xpath("//input[@name='uid']")).sendKeys("mngr580849");
	driver1.findElement(By.xpath("//input[@name='password']")).sendKeys("guqEjed");
	driver1.findElement(By.xpath("//input[@name='btnLogin']")).click();
String Title2=	driver1.getTitle();
System.out.println(Title2);

if(Title2.contains("HomePage"))
{
	System.out.println("Test case passed");
}
else
{
	System.out.println("Test case failed");
}

WebElement ele3=driver1.findElement(By.xpath("//a[text()='Log out']"));
if(ele3.isDisplayed()==true && ele3.isEnabled()==true)
{
	ele3.click();
}
		

driver1.switchTo().alert().accept();
String Ttitle3=driver1.getTitle();
System.out.println(Ttitle3);
	
	
	
		

	}

}
