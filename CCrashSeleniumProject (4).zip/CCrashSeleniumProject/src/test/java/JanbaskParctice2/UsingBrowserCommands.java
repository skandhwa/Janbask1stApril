package JanbaskParctice2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class UsingBrowserCommands {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.navigate().to("https://www.google.com");
	String CurrentURL=	driver.getCurrentUrl();
	System.out.println(CurrentURL);
	driver.manage().window().maximize();
//	driver.navigate().back();
//	Thread.sleep(3000);
//	driver.navigate().forward();
//	Thread.sleep(3000);
//	driver.navigate().refresh();
//	Thread.sleep(3000);
	driver.findElement(By.xpath("//textarea[@class='gLFyf']")).sendKeys("Java Language");
	boolean flag=driver.findElement(By.xpath("//textarea[@class='gLFyf']")).isEnabled();
	System.out.println(flag);
	boolean flag2=driver.findElement(By.xpath("//textarea[@class='gLFyf']")).isDisplayed();
	System.out.println(flag2);
	Thread.sleep(3000);
	driver.findElement(By.xpath("//textarea[@class='gLFyf']")).clear();
	Thread.sleep(3000);
	driver.findElement(By.xpath("(//a[@class='gb_x'])[1]")).click();
	
	
	
	
	
		

	}

}
