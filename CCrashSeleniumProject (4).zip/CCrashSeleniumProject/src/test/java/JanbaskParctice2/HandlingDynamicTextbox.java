package JanbaskParctice2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingDynamicTextbox {

	public static void main(String[] args) {
		
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.tutorialspoint.com/selenium/practice/selenium_automation_practice.php");
	
	driver.manage().window().maximize();
String Text=	driver.findElement(By.xpath("//label[@for='name']")).getText();
System.out.println(Text);
String value=driver.findElement(By.xpath("//input[@name='name']")).getAttribute("id");
System.out.println(value);


	
	

	}

}
