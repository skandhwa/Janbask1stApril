package SeleniumCommands;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebElementCommands6 {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.tutorialspoint.com/selenium/practice/selenium_automation_practice.php");
		WebElement ele=driver.findElement(By.xpath("//input[@name='name']"));
	   String ID=	ele.getAttribute("id");
	   System.out.println(ID);
	   
	   
	   Dimension d=ele.getSize();
	   System.out.println(d.height);
	   System.out.println(d.width);
	   
	   
	   Point p=ele.getLocation();
	   
	int x=   p.getX();
	 int y=  p.getY();
	 
	 System.out.println(x);
     System.out.println(y);	   
	   
		

	}

}
