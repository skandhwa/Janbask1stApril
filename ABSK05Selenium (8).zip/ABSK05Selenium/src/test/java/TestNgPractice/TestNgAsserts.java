package TestNgPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TestNgAsserts {
	
	@Test
	public void test1()
	{
	
	int x=10;
	int y=20/2;
	Assert.assertEquals(x,y);
	
	}
	
	
	@Test
	public void checkTitle()
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com");
	String Title=	driver.getTitle();
	System.out.println(Title);
	Assert.assertEquals("Google", Title);
	Assert.assertNotEquals(5,3);
	boolean flag=5>3;
	
//	Assert.assertFalse(flag);
//	Assert.assertTrue(flag);
	int y=10/2;
	int z=5;
//	
	
	Assert.assertSame(y, z);
	
	
	
	
	
		
	}
	
	
	
	

}
