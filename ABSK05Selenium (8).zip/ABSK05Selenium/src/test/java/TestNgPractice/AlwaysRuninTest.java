package TestNgPractice;

import org.testng.annotations.Test;

public class AlwaysRuninTest {
	
	@Test(successPercentage=50)
    public void test1()
    {
		System.out.println("Hello");
		int x=9/0;
		System.out.println(x);
    }
	public void test1b()
    {
		System.out.println("Hello");
		
    }
	
	

	@Test(dependsOnMethods= {"test1"},alwaysRun=true)
    public void test2()
    {
		System.out.println("Hello I am new");
    }
	
	
	@Test()
    public void test3()
    {
		System.out.println("Hello I am new 3");
    }
}
