package TestNgPractice;

import org.testng.annotations.Test;

public class UsingMultiDependsOn {
	
	@Test
	public void openBrowser()
	{
		System.out.println("Opening the browser");
		int x=9/0;
		System.out.println(x);
	}
	
	@Test(dependsOnMethods= {"openBrowser"})
	public void signIn()
	{
		System.out.println("SignIn functionality");
	}
	
	@Test(dependsOnMethods= {"openBrowser","signIn"})
	public void searchProduct()
	{
		System.out.println("Search a product");
	}
	

	@Test(dependsOnMethods= {"signIn","searchProduct"})
	public void addToCart()
	{
		System.out.println("adding item to cart");
	}
	
	
	
	
	

}
