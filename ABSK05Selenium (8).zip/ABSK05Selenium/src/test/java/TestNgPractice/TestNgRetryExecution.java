package TestNgPractice;

import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

public class TestNgRetryExecution implements IRetryAnalyzer {

	int retrylimit=3;
	int count=0;
	
	public boolean retry(ITestResult result) {
		
		if(count<retrylimit)///1<3
		{
			count++;
			return true;
		}
		
		
		
		
		return false;
	}
	
	

}
