package AdvanceSelenium;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class CopyPasteOperationActionClass {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demoqa.com/text-box");
		driver.manage().window().maximize();
	WebElement firstname=	driver.findElement(By.xpath("//input[@id='userName']"));
		firstname.sendKeys("Saurabh");
		WebElement Email=driver.findElement(By.xpath("//input[@id='userEmail']"));
		Email.sendKeys("sk1234@gmail.com");
	WebElement CAddress=	driver.findElement(By.xpath("//textarea[@placeholder='Current Address']"));
	CAddress.sendKeys("Prabhakar Appartment Tollygunge Kolkata-700033 West bengal ");
	Actions act=new Actions(driver);
	
	///// SELECT THE ENTIRE CONTENT
	
	act.keyDown(Keys.CONTROL);
	act.sendKeys("a");
	act.keyUp(Keys.CONTROL);
	act.build().perform();
	
	
	///COPY THE ENTIRE CONTENT
	
	act.keyDown(Keys.CONTROL);
	act.sendKeys("c");
	act.keyUp(Keys.CONTROL);
	act.build().perform();
	
	////Pressing the tab button to focus
	
	act.sendKeys(Keys.TAB);
	act.build().perform();
	Thread.sleep(3000);
	
	
	////PASTE the entire content
	
	act.keyDown(Keys.CONTROL);
	act.sendKeys("v");
	act.keyUp(Keys.CONTROL);
	act.build().perform();
	
	
	

	}

}
