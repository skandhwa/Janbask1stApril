package AdvanceSelenium;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingMultipleWindows {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver= new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Windows.html");
		driver.manage().window().maximize();
		String WindowID=	driver.getWindowHandle();
		System.out.println(WindowID);
		
		driver.findElement(By.xpath("//a[@href='#Seperate']")).click();
		driver.findElement(By.xpath("//button[@class='btn btn-primary']")).click();
		
		
		Set<String> windowIDs=	driver.getWindowHandles();
		System.out.println("Window handle values are");
		
		for(String x:windowIDs)
		{
			System.out.println(x);
		}
		Iterator<String> itr= windowIDs.iterator();
		while(itr.hasNext())
		{
			String childwindow=itr.next();
			if(!WindowID.equals(childwindow))
			{
				driver.switchTo().window(childwindow);
				String TitleNew=driver.getTitle();
				System.out.println(TitleNew);
				Thread.sleep(5000);
				driver.close();
			}
			
			driver.switchTo().window(WindowID);
			String TitleNew=driver.getTitle();
			System.out.println(TitleNew);
		

	}

}
}
