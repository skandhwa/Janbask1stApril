package AdvanceSelenium;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingWindows {

	public static void main(String[] args) {
		
		WebDriver driver= new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Windows.html");
		driver.manage().window().maximize();
		String WindowID=	driver.getWindowHandle();
		System.out.println(WindowID);
		driver.findElement(By.xpath("(//button[@class='btn btn-info'])[1]")).click();
//		String WindowID2=	driver.getWindowHandle();
//		System.out.println(WindowID2);
		
	Set<String> s1=	driver.getWindowHandles();
	System.out.println(s1);
	
	String Title=driver.getTitle();
	System.out.println(Title);
	
		
		
		
		
		
	
		

	}

}
