package StaticKeyword;

class G3
{
	static void display()
	{
		System.out.println("Hello");
	}
}


public class UsingStaticMethods {

	public static void main(String[] args) {
		
		G3.display();
		
		
		
		

	}

}
