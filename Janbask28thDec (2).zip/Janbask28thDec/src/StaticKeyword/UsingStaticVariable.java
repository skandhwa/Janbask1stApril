package StaticKeyword;

class G1
{
	int id;
	String name;
	static String company="Accenture";
	
	G1(int i,String n)
	{
		id=i;
		name=n;
		
	}
	
	void display()
	{
		System.out.println(id+"  "+name+"  "+company);
	}
	
	
	
	
}

public class UsingStaticVariable {

	public static void main(String[] args) {
		
		G1 obj=new G1(1234,"Monty");
		G1 obj1=new G1(3456,"Tom");
		G1 obj2=new G1(8456,"Mat");
		
		obj.display();
		obj1.display();
		obj2.display();

	}

}
