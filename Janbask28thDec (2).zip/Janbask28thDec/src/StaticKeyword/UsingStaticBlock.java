package StaticKeyword;

public class UsingStaticBlock {
	
	static
	{
		System.out.println("How are you");
	}
	

	public static void main(String[] args) {
		
		System.out.println("Hi");
		

	}

}
