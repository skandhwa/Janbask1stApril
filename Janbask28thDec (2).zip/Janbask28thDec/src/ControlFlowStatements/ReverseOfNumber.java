package ControlFlowStatements;

public class ReverseOfNumber {

	public static void main(String[] args) {
		
		int num=123;
		int sum=0;
	    int reverse=0;
		
		while(num!=0)/////123!=0
		{
			int r =num%10;///r=3
			reverse=reverse*10+r;///reverse=0*10+3=3
			num=num/10;//num=
			
		}
		
		System.out.println("reverse of number is "+reverse);
		
		

	}

}
