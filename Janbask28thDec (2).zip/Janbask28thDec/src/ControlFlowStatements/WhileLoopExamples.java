package ControlFlowStatements;

public class WhileLoopExamples {

	public static void main(String[] args) {
		
		int x=5;/// assignment operation
		
		while(x<100)///Condition checking
		{
			System.out.println(x);//5//6//7
			x++;//Increment/decrement opearation
		}
		
		
		

	}

}
