package ControlFlowStatements;

public class sumOfDigits {

	public static void main(String[] args) {
		
		int num=289;
		int sum=0;
		
		while(num!=0)///289!=0/// 28!=0///2!=0//0!=0
		{
			int r=num%10;///9////r=28%10=8////r=2%10=2
			sum=sum+r;///sum=0+9=9//sum=9+8=17///sum=17+2=19
			num=num/10;//num=289/10=28///num=28/10=2///2/10=0
		}
		
		System.out.println(sum);

	}

}
