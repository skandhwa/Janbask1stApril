package ControlFlowStatements;

public class forLoopExample {

	public static void main(String[] args) {
		
		for(int i=0;i<5;i++)//i=0, 0<5///i=1,1<5//i=2,2<5...i=5,5<5
		{
			System.out.println(i);//0//1//2
		}
		

	}

}
