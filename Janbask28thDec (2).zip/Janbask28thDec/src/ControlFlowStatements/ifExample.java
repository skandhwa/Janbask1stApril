package ControlFlowStatements;

public class ifExample {

	public static void main(String[] args) {
		
		int age=40;
		char status='A';
		
		if(age>18)
		{
			if(status=='B')
			{
				System.out.println("Yes this is fine");
			}
		}
		
		

	}

}
