package ControlFlowStatements;

public class NestedForLoopEx {

	public static void main(String[] args) {
		
		for(int i=0;i<=2;i++)//i=0,0<=2
		{
			for(int j=0;j<=2;j++)////j=0,0<=2///j=1,1<=2
			{
				System.out.println(i+"  "+j);///0....0////0..1
			}
		}
		

	}

}
