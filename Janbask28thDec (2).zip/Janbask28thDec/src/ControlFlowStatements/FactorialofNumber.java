package ControlFlowStatements;

public class FactorialofNumber {

	public static void main(String[] args) {
		
		int fact=1;
		
		int n=5;
		
		for(int i=1;i<=n;i++)///i=1,1<=5 ..//i=2,2<=5///i=3,3<=5
		{
			fact=fact*i;///fact=1*1=1// fact=1*2=2/// fact= 2*3=6
		}
		
		System.out.println("Factorial of number is "+fact);

	}

}
