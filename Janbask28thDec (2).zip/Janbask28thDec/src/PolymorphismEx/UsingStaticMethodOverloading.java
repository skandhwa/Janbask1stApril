package PolymorphismEx;

public class UsingStaticMethodOverloading {
	
	static int sum(int a,int b)
	{
		return a+b;
	}
	
	static int sum(int a,int b,int c)
	{
		return a+b+c;
	}
	
	
	

	public static void main(String[] args) {
		
	System.out.println(UsingStaticMethodOverloading.sum(12,32));  
	System.out.println(UsingStaticMethodOverloading.sum(12,32,78));	

	}

}
