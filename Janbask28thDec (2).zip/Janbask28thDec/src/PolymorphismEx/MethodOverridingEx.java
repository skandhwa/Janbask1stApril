package PolymorphismEx;

class Bank
{
	int getROI(int x,int y)
	{
		return x+y;
	}
}

class BOA extends Bank
{
	int getROI(int x,int y)
	{
		return x+y;
	}
}

class FB extends Bank
{
	int getROI(int x,int y)
	{
		return x+y;
	}
	
}

class HSBC extends Bank
{
int getROI(int x,int y)
{
	return x+y;
}
}



public class MethodOverridingEx {

	public static void main(String[] args) {
		
		
	Bank obj=new Bank();
System.out.println(obj.getROI(12, 10));	
	
	FB obj1=new FB();
	System.out.println	(obj1.getROI(4, 7));

	}

}
