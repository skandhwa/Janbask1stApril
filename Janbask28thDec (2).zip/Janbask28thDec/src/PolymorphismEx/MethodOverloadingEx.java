package PolymorphismEx;

public class MethodOverloadingEx {
	
	void display(int x,int y)
	{
		System.out.println(x+y);
	}
	
	void display(int a,float b)
	{
		System.out.println(a+b);
	}
	

	public static void main(String[] args) {
		
		
		MethodOverloadingEx obj=new MethodOverloadingEx();
		obj.display(12,32);
		MethodOverloadingEx obj1=new MethodOverloadingEx();
		obj.display(22,32.56f);
		
		

	}

}
