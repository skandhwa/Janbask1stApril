package ClassObjectConstructor;

class C
{
	void display()
	{
		System.out.println("Hello");
	}
	
	int display1(int x,int y)
	{
		
		return x+y;
	}
	
}



public class MethodExamples {

	public static void main(String[] args) {
		
		C obj=new C();
		obj.display();
		
		System.out.println(obj.display1(20,30));
		
		
		

	}

}
