package ClassObjectConstructor;

class A
{
	A()
	{
		System.out.println("Hii");
	}
	
	
	void display()
	{
		System.out.println("Hello");
	}
}

public class ClassObjectConstructor1 {

	public static void main(String[] args) {
		
		A obj=new A();
		obj.display();
		
		
		
		
		

	}

}
