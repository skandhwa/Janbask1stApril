package ClassObjectConstructor;

class B
{
	
	B()
	{
		System.out.println("Hello");
	}
	void display()
	{
		System.out.println("Hello");
	}
}



public class ClassObjectConstructor2 {

	public static void main(String[] args) {
		
		B obj=new B();
		obj.display();
		
		

	}

}
