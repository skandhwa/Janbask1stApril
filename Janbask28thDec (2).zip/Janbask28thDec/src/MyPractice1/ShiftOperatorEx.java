package MyPractice1;

public class ShiftOperatorEx {

	public static void main(String[] args) {
		
//		int x=30;
//		
//		System.out.println(x<<2);////20* 2pow2=20*4=80
//		
//		///30*2*2=120
		
		int y=60;
		
		System.out.println(y>>3);/// 60>>3 = 60/2pow3= 60 /8
		
		
		
		

	}

}
