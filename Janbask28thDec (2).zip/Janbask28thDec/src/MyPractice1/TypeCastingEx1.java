package MyPractice1;

public class TypeCastingEx1 {

	public static void main(String[] args) {
		
//		int x=10;
//		
//		byte y=(byte)x;
//		
//		System.out.println(y);
		
		
//		float x=23.56f;
//		
//		double y=x;
		
	    double z=34.321321f;
	    
	    long p=(long) z;
	    
	    System.out.println(p);
		
		
		
		
		

	}

}
