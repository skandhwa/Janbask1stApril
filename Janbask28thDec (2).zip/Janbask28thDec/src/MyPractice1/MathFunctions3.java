package MyPractice1;

public class MathFunctions3 {

	public static void main(String[] args) {
		
		int x=20;
		double y=30;
		
	System.out.println(Math.cos(y));
	
	System.out.println(Math.floor(y));
	
	System.out.println(Math.ceil(y));
	
	System.out.println(Math.multiplyExact(x, x));
	
	
	System.out.println(Math.incrementExact(x));
		
		
		

	}

}
