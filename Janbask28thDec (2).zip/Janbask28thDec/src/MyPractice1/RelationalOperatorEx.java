package MyPractice1;

public class RelationalOperatorEx {

	public static void main(String[] args) {
		
		int a=40;
		int b=20;
		int c=25;
		
		if(a<b || b>c || c<a )//40<20 ,,,20>25,,,25<40
		{
			System.out.println("true");
		}
		else
		{
			System.out.println("false");
		}
		
		//// > , >= ,< , <= 
		
		///40>=40

	}

}
