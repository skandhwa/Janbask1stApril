package MyPractice1;

public class AssignmentOperatorEx {

	public static void main(String[] args) {
		
		int x=50;
		
		x+=20;
		
		System.out.println(x);  ///x=x+20= 30+20=50
		

	}

}
