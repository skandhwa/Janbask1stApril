package MyPractice1;

public class UsingTernaryOperatorEx {

	public static void main(String[] args) {
		
		
		int a=20;
		int b=40;
		
		int max= a>b?a:b;
		
		
		
		
//		if(a<b)
//		{
//			System.out.println("a is maximum");
//		}
//		
//		else
//		{
//			System.out.println("b is maximum");
//		}

	}

}
