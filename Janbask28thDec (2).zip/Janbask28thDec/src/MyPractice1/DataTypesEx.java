package MyPractice1;

public class DataTypesEx {

	public static void main(String[] args) {
		
		
		System.out.println(10 + 20 + "Java" + 10 + 20);

		
		
	}

}
