package MyPractice1;

public class Operators1 {

	public static void main(String[] args) {
		
//		int x=10;
//		
//		int y= x--;
//		
//		System.out.println(y);
		
		int x=20;
		int y=x*6;
		
		System.out.println(y);
		
		
		
		
		

	}

}
