package UsingStaticMethods;

public class StaticMethods2 {
	
	static void test()
	{
		System.out.println("Hello");
	}
	
	

	public static void main(String[] args) {
		
		StaticMethods2.test();

	}

}
