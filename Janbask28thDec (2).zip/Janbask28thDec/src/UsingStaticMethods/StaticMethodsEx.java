package UsingStaticMethods;

class Test
{
	static void display()
	{
		System.out.println("Hello");
	}
}



public class StaticMethodsEx {

	public static void main(String[] args) {
		
		Test.display();
		
		

	}

}
