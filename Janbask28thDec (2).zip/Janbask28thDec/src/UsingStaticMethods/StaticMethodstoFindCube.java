package UsingStaticMethods;

public class StaticMethodstoFindCube {
	
	static int cube(int x)
	{
		return x*x*x;
	}
	

	public static void main(String[] args) {
		
		
	System.out.println(StaticMethodstoFindCube.cube(9));	

	}

}
