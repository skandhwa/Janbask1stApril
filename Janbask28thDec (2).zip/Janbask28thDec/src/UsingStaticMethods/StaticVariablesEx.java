package UsingStaticMethods;

public class StaticVariablesEx {
	
	int id;
	String name;
	static String CompanyName;
	StaticVariablesEx(int i,String n)
	{
		id=i;
		name=n;
		
	}
	void display()
	{
		System.out.println(id+"  "+name+"  "+CompanyName);
	}
	
	

	public static void main(String[] args) {
		
		StaticVariablesEx obj=new StaticVariablesEx(23,"Saurabh");
		obj.display();
		StaticVariablesEx obj1=new StaticVariablesEx(13,"Gaurabh");
		obj.display();
		StaticVariablesEx obj2=new StaticVariablesEx(93,"Manish");
		obj.display();

	}

}
