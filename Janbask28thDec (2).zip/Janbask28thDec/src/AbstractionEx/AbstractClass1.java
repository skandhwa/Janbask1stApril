package AbstractionEx;

abstract class Bike
{
	abstract void display();
	void test()
	{
		System.out.println("Hello");
	}
	
}



public class AbstractClass1 {

	public static void main(String[] args) {
		

	}

}
