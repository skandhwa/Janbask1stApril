package OOPSConcept;

class T5
{
	void display()
	{
		System.out.println("Hello");
	}
}

class T6 extends T5
{
	void display()
	{
		System.out.println("Hi");
	}
	
	
	void test()
	{
		super.display();
		display();
		
	}
}



public class UsingSuperforMethods {

	public static void main(String[] args) {
		
		T6 obj=new T6();
		obj.test();
		obj.display();
		

	}

}
