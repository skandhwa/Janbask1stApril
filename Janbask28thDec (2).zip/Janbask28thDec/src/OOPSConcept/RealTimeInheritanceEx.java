package OOPSConcept;

class Diagram
{
	void rectangle()
	{
		System.out.println("Drawing rectangle");
	}
}

class Shape extends Diagram
{
	void circle()
	{
		System.out.println("Drawing Circle");
	}
}

class Draw extends Diagram
{
	void square()
	{
		System.out.println("Drawing square");
	}
}




public class RealTimeInheritanceEx {

	public static void main(String[] args) {
		
		Draw obj=new Draw();
		obj.square();
		obj.rectangle();
		
		
		
		

	}

}
