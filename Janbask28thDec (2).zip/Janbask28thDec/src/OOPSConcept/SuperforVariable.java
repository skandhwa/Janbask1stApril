package OOPSConcept;

class P7
{
	String colour="red";
}

class P8 extends P7
{
	String colour="blue";
	void display()
	{
		System.out.println(colour);
		System.out.println(super.colour);
	}
	
	
}

public class SuperforVariable {

	public static void main(String[] args) {
		
		P8 obj=new P8();
		obj.display();
		

	}

}
