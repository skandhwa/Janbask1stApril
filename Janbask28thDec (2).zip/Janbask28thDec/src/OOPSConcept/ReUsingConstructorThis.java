package OOPSConcept;

class T9
{
	int id;
	String name;
	String address;
	T9(int id,String name)
	{
		this.id=id;
		this.name=name;
	}
	
	T9(int id,String name,String address)
	{
		this(id,name);
		this.address=address;
	}
	
	void display()
	{
		System.out.println(id+"  "+name+" "+address);
	}
	
	
	
}



public class ReUsingConstructorThis {

	public static void main(String[] args) {
		
		T9 obj=new T9(1234,"John");
		obj.display();
		T9 obj1=new T9(1234,"John","NY");
		obj1.display();

	}

}
