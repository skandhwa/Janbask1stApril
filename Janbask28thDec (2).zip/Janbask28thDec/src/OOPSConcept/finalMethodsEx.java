package OOPSConcept;

class Bank
{
	final int getROI(int x,int y)
	{
		return x+y;
	}
}

class HDFC extends Bank
{
	int getROI(int x,int y)
	{
		return x+y;
	}
}



public class finalMethodsEx {

	public static void main(String[] args) {
		

	}

}
