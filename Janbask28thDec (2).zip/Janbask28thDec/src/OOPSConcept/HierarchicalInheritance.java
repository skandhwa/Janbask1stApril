package OOPSConcept;

class P1
{
	void display()
	{
		System.out.println("Hello");
	}
}

class P2 extends P1
{
	void test()
	{
		System.out.println("Hi");
	}
}

class P3 extends P1
{
	void message()
	{
		System.out.println("Hey how r u");
	}
}




public class HierarchicalInheritance {

	public static void main(String[] args) {
		
		P3 obj=new P3();
		obj.display();
		obj.message();
		

	}

}
