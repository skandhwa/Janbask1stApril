package OOPSConcept;

class D1
{
	String name;
	int id;
	String address;
	D1(String n1,int id1)
	{
		name=n1;
		id=id1;
	}
	
	
	
	D1(String n,int i,String a)
	{
		super(n,i);
		address=a;
	}
	
	
	
	
	
}


public class SuperforConstructor {

	public static void main(String[] args) {
		

	}

}
