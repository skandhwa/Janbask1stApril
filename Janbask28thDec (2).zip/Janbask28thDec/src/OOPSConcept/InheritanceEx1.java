package OOPSConcept;

class T1
{
	void display()
	{
		System.out.println("Hello");
	}
}

class T2 extends T1
{
	void test()
	{
		System.out.println("Hi");
	}
}

class T3 extends T2
{
	void message()
	{
		System.out.println("Hey how r u");
	}
}



public class InheritanceEx1 {

	public static void main(String[] args) {
		
		T3 obj=new T3();
		obj.test();
		obj.display();
		obj.message();

	}

}
