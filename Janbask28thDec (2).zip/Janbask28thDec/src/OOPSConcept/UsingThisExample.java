package OOPSConcept;

class T4
{
	int id;
	String name;
	String address;
	T4(int id,String name,String address)
	{
		this.id=id;
		this.name=name;
		this.address=address;
	}
	void display()
	{
		System.out.println(id+" "+name+"  "+address);
	}
}

public class UsingThisExample {

	public static void main(String[] args) {
		
		T4 obj=new T4(12,"Monty","Kolkata");
		obj.display();
		
	}

}
