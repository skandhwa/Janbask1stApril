package OOPSConcept;

public class finalClassEx {

	public static void main(String[] args) {
		

	}

}
