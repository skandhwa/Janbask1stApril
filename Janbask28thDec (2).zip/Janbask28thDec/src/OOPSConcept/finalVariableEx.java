package OOPSConcept;

class Car
{
	final int speed=40;
	void display()
	{
		 speed=60;
		System.out.println(speed);
	}
	
}



public class finalVariableEx {

	public static void main(String[] args) {
		
		Car obj=new Car();
		obj.display();
		

	}

}
